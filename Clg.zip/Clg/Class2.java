// ...existing code...
public class Class2 {
    public static void main(String[] args) {
        java.util.Scanner sc = new java.util.Scanner(System.in);
        System.out.print("Enter an integer: ");
        if (!sc.hasNextInt()) {
            System.out.println("Invalid input");
            sc.close();
            return;
        }
        int n = sc.nextInt();
        sc.close();
        System.out.println(n % 2 == 0 ? "Even" : "Odd");
    }
}
// ...existing code...