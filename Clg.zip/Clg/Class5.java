// ...existing code...
import java.util.*;

public class Class5 {
    static class Student {
        String name;
        int roll;
        double marks;

        Student(String name, int roll, double marks) {
            this.name = name;
            this.roll = roll;
            this.marks = marks;
        }

        void display() {
            System.out.printf("Roll: %d, Name: %s, Marks: %.2f%n", roll, name, marks);
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("How many students? ");
        int n = sc.hasNextInt() ? sc.nextInt() : 0;
        sc.nextLine(); // consume newline

        List<Student> students = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.printf("Student %d name: ", i + 1);
            String name = sc.nextLine();

            System.out.printf("Student %d roll no: ", i + 1);
            int roll = sc.hasNextInt() ? sc.nextInt() : 0;

            System.out.printf("Student %d marks: ", i + 1);
            double marks = sc.hasNextDouble() ? sc.nextDouble() : 0.0;
            sc.nextLine(); // consume newline

            students.add(new Student(name, roll, marks));
        }
        sc.close();

        System.out.println("\nStored students:");
        for (Student s : students) s.display();
    }
}
// ...existing code...