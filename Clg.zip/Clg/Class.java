// ...existing code...
class Student {
    int id;
    String name;
    double salery;

    Student(int id, String name, double salery) {
        this.id = id;
        this.name = name;
        this.salery = salery;
    }

    void display() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Salery: " + salery);
    }

    public static void main(String[] args) {
        Student s = new Student(1, "Alice", 50000.0);
        s.display();
    }
}
// ...existing code...
